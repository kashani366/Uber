package presistance;

import model.UberDriver;

public interface UberDriverDao {
    void addDriver(UberDriver driver);
}
